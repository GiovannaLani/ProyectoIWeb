from django.contrib import admin
from .models import Temporada, Escuela, Personaje

admin.site.register(Temporada)
admin.site.register(Escuela)
admin.site.register(Personaje)